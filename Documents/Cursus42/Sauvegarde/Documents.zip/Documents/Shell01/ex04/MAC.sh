ifconfig | grep -e "ether" -e "lladdr" | cut -d" " -f2
