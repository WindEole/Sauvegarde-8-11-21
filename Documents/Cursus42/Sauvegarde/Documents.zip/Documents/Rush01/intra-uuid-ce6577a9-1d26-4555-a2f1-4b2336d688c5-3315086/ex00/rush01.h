/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush01.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: inhow-ch <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/20 18:17:52 by inhow-ch          #+#    #+#             */
/*   Updated: 2020/09/20 18:41:18 by inhow-ch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef RUSH01_H
# define RUSH01_H
# include <stdlib.h>
# include <unistd.h>

int		ft_security(char *str);
void	ft_av_to_data(char **data, char *str);
char	**ft_malloc(char **tab, int line, int column);
void	ft_free_malloc(char **tab, int line);
int		ft_check_line(char *data_lign, char left, char right);
int		ft_final_check(char **tab, char **data);

void	ft_strcpy(char *dest, char *src);

#endif
