/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_check_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: inhow-ch <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/20 17:38:40 by inhow-ch          #+#    #+#             */
/*   Updated: 2020/09/20 17:39:35 by inhow-ch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_check_line_right(char *data_lign, char right)
{
	int		i;
	char	numbers_buildings;
	char	max_size;

	numbers_buildings = '1';
	max_size = data_lign[3];
	i = 2;
	while (i >= 0)
	{
		if (data_lign[i] > max_size)
		{
			numbers_buildings++;
			max_size = data_lign[i];
		}
		i--;
	}
	if (numbers_buildings != right)
		return (0);
	return (1);
}

int		ft_check_line_left(char *data_lign, char left)
{
	int		i;
	char	numbers_buildings;
	char	max_size;

	i = 1;
	numbers_buildings = '1';
	max_size = data_lign[0];
	while (i < 4)
	{
		if (data_lign[i] > max_size)
		{
			max_size = data_lign[i];
			numbers_buildings++;
		}
		i++;
	}
	if (numbers_buildings != left)
		return (0);
	return (1);
}

int		ft_check_line(char *data_lign, char left, char right)
{
	if (!ft_check_line_left(data_lign, left))
		return (0);
	if (!ft_check_line_right(data_lign, right))
		return (0);
	return (1);
}
