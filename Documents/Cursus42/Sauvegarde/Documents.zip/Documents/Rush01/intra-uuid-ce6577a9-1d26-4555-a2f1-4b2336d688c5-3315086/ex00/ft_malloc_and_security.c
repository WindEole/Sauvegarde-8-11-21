/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_malloc_and_security.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: inhow-ch <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/20 17:44:58 by inhow-ch          #+#    #+#             */
/*   Updated: 2020/09/20 17:50:46 by inhow-ch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	**ft_malloc(char **tab, int line, int column)
{
	int i;

	if (!(tab = (char**)(malloc(sizeof(char*) * line))))
		return (0);
	i = 0;
	while (i < line)
	{
		if (!(tab[i] = (char*)(malloc(sizeof(char) * column))))
			return (0);
		i++;
	}
	return (tab);
}

void	ft_free_malloc(char **tab, int line)
{
	int i;

	i = 0;
	while (i < line)
	{
		free(tab[i]);
		i++;
	}
	free(tab);
}

int		ft_security(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
	{
		if (i % 2 == 0)
		{
			if (!(str[i] >= '1' && str[i] <= '4'))
				return (0);
		}
		else
		{
			if (str[i] != ' ')
				return (0);
		}
		i++;
	}
	if (i != 31)
		return (0);
	return (1);
}
