/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_final_check.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: inhow-ch <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/20 17:33:24 by inhow-ch          #+#    #+#             */
/*   Updated: 2020/09/20 17:34:39 by inhow-ch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_check_column_case(char **tab, int column)
{
	int i;
	int j;

	i = 0;
	while (i < 4)
	{
		j = i + 1;
		while (j < 4)
		{
			if (tab[i][column] == tab[j][column])
				return (0);
			j++;
		}
		i++;
	}
	return (1);
}

int		ft_final_check_column_top(char **tab, char top, int column)
{
	int		i;
	char	numbers_buildings;
	char	max_size;

	i = 1;
	numbers_buildings = '1';
	max_size = tab[0][column];
	while (i < 4)
	{
		if (tab[i][column] > max_size)
		{
			max_size = tab[i][column];
			numbers_buildings++;
		}
		i++;
	}
	if (numbers_buildings != top)
		return (0);
	return (1);
}

int		ft_final_check_column_down(char **tab, char down, int column)
{
	int		i;
	char	numbers_buildings;
	char	max_size;

	numbers_buildings = '1';
	max_size = tab[3][column];
	i = 2;
	while (i >= 0)
	{
		if (tab[i][column] > max_size)
		{
			numbers_buildings++;
			max_size = tab[i][column];
		}
		i--;
	}
	if (numbers_buildings != down)
		return (0);
	return (1);
}

int		ft_final_check(char **tab, char **data)
{
	int column;

	column = 0;
	while (column < 4)
	{
		if (!ft_check_column_case(tab, column))
			return (0);
		if (!ft_final_check_column_down(tab, data[1][column], column))
			return (0);
		if (!ft_final_check_column_top(tab, data[0][column], column))
			return (0);
		column++;
	}
	return (1);
}
