/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_data.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: inhow-ch <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/20 17:46:36 by inhow-ch          #+#    #+#             */
/*   Updated: 2020/09/21 17:44:43 by iderighe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_strcpy(char *dest, char *src)
{
	int i;

	i = 0;
	while (src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
}

void	ft_option(char **data)
{
	ft_strcpy(data[4], "1234");
	ft_strcpy(data[5], "1243");
	ft_strcpy(data[6], "1324");
	ft_strcpy(data[7], "1342");
	ft_strcpy(data[8], "1423");
	ft_strcpy(data[9], "1432");
	ft_strcpy(data[10], "2134");
	ft_strcpy(data[11], "2143");
	ft_strcpy(data[12], "2314");
	ft_strcpy(data[13], "2341");
	ft_strcpy(data[14], "2413");
	ft_strcpy(data[15], "2431");
	ft_strcpy(data[16], "3124");
	ft_strcpy(data[17], "3142");
	ft_strcpy(data[18], "3214");
	ft_strcpy(data[19], "3241");
	ft_strcpy(data[20], "3412");
	ft_strcpy(data[21], "3421");
	ft_strcpy(data[22], "4123");
	ft_strcpy(data[23], "4132");
	ft_strcpy(data[24], "4213");
	ft_strcpy(data[25], "4231");
	ft_strcpy(data[26], "4312");
	ft_strcpy(data[27], "4321");
}

void	ft_av_to_data(char **data, char *str)
{
	int i;

	i = 0;
	while (i < 4)
	{
		data[i][0] = str[(i * 8)];
		data[i][1] = str[(i * 8) + 2];
		data[i][2] = str[(i * 8) + 4];
		data[i][3] = str[(i * 8) + 6];
		data[i][4] = '\0';
		i++;
	}
	ft_option(data);
}
