/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tab_generator.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bmerchin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/19 15:52:14 by bmerchin          #+#    #+#             */
/*   Updated: 2020/09/20 19:03:05 by inhow-ch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush01.h"

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_print(char **tab)
{
	int i;
	int j;

	i = 0;
	j = 0;
	while (i < 4)
	{
		j = 0;
		while (j < 4)
		{
			ft_putchar(tab[i][j]);
			if (j != 3)
				ft_putchar(' ');
			j++;
		}
		ft_putchar('\n');
		i++;
	}
}

int		*ft_tab_generator(char **tab, char **data, int lign, int *printed)
{
	int i;

	i = 4;
	while (i < 28)
	{
		if (ft_check_line(data[i], data[2][lign], data[3][lign]))
		{
			ft_strcpy(tab[lign], data[i]);
			if (lign < 3)
				ft_tab_generator(tab, data, lign + 1, printed);
			else if (ft_final_check(tab, data) && *printed == 0)
			{
				ft_print(tab);
				*printed += 1;
			}
		}
		i++;
	}
	return (printed);
}

int		main(int ac, char **av)
{
	char	**tab;
	char	**data;
	int		printed;

	tab = 0;
	data = 0;
	printed = 0;
	if (ac != 2 || !ft_security(av[1]))
	{
		write(1, "Error\n", 6);
		return (0);
	}
	tab = ft_malloc(tab, 4, 5);
	data = ft_malloc(data, 28, 5);
	if (tab == 0 || data == 0)
		return (0);
	ft_av_to_data(data, av[1]);
	if (*ft_tab_generator(tab, data, 0, &printed) == 0)
		write(1, "Error\n", 6);
	ft_free_malloc(data, 28);
	ft_free_malloc(tab, 4);
	return (0);
}
