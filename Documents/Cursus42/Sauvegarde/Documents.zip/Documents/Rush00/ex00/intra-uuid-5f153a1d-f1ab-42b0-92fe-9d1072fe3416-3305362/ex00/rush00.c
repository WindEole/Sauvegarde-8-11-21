/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tthibaut <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/12 11:36:27 by tthibaut          #+#    #+#             */
/*   Updated: 2020/09/13 12:52:06 by tthibaut         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ft_putlines(int x)
{
	int compteur;

	compteur = x - 2;
	ft_putchar('o');
	while (compteur > 0)
	{
		ft_putchar('-');
		compteur--;
	}
	if (x > 1)
		ft_putchar('o');
	ft_putchar('\n');
}

void	ft_putvertical(int x, int y)
{
	int compteur;

	compteur = x - 2;
	while ((y - 2) > 0)
	{
		ft_putchar('|');
		while (compteur > 0)
		{
			ft_putchar(' ');
			compteur--;
		}
		compteur = x - 2;
		if (x > 1)
			ft_putchar('|');
		ft_putchar('\n');
		y--;
	}
}

void	rush(int x, int y)
{
	if (x > 0 && y > 0)
	{
		ft_putlines(x);
		ft_putvertical(x, y);
		if (y > 1)
			ft_putlines(x);
	}
}
