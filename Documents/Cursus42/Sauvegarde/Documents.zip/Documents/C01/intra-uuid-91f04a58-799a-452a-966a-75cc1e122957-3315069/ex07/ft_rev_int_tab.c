/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: iderighe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/19 10:45:55 by iderighe          #+#    #+#             */
/*   Updated: 2020/09/19 11:12:43 by iderighe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_swap(int *a, int *b)
{
	int c;

	c = *a;
	*a = *b;
	*b = c;
}

void	ft_rev_int_tab(int *tab, int *size)
{
	int i;

	i = 0;
	while (i < size && size < 2)
	{
		ft_swap(&tab[i], &tab[size - 1 - i]);
		i++;
	}
}
